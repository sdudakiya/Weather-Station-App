import { Component } from '@angular/core';
import { NavController } from 'ionic-angular';
import { RestProvider } from '../../providers/rest/rest';
import { SearchPage } from '../search/search';


@Component({
  selector: 'page-home',
  templateUrl: 'home.html'
})
export class HomePage {
  
  users: any;
  form_data = {};
  logForm() {
    console.log(this.form_data);
    this.savePost();
  }
  
  constructor(public navCtrl: NavController, public restProvider: RestProvider) {
    this.getUsers();
  }

  getUsers() {
    this.restProvider.getUsers()
    .then(data => {
      this.users = data;
      console.log(this.users);
    });
  }

  savePost() {
    this.restProvider.addPost(this.form_data).then((result) => {
      console.log(result);
    }, (err) => {
      console.log(err);
    });
  }

  gotoSearch() {
    this.navCtrl.setRoot(SearchPage);
  }
}
