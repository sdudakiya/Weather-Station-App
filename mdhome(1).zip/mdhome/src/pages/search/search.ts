import { Component } from '@angular/core';
import { IonicPage, NavController, NavParams } from 'ionic-angular';
import { RestProvider } from '../../providers/rest/rest';

@IonicPage()
@Component({
  selector: 'page-search',
  templateUrl: 'search.html',
})
export class SearchPage {
searchresult = any;

  form_data = {};
  logForm() {
    console.log(this.form_data);
    this.searchPost();
  }

  constructor(public navCtrl: NavController, public navParams: NavParams, public restProvider: RestProvider) {
  }

  ionViewDidLoad() {
    console.log('ionViewDidLoad SearchPage');
  }

  searchPost() {
    this.restProvider.searchPost(this.form_data).then((result) => {
    this.searchresult = result;
      console.log(result);
    }, (err) => {
      console.log(err);
    });
  }

}
